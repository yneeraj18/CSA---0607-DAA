# CSA06 – CO1 Assessment Tool 1: Scalability Audit of ShopSphere

Assumption throughout: 10⁸ basic operations per second; logs are base 2; n = 100,000 now and 1,000,000 next year.

---
## (a) Understanding the problem

| Module | Input size | Basic operation | Where it occurs | Expected growth |
|---|---|---|---|---|
| M1 | n = number of products | The `title = title AND seller = seller` comparison | Innermost body of the nested loop, once per pair (i, j) | Quadratic: every product is compared with every later one, so the work grows with the number of pairs |
| M2 | n = request-window limit | `Audit(Request[j])` | Inner loop; its trip count equals the current i, which doubles | Linear (geometric series dominated by the last term), *not* n log n |
| M3 (S1, S2) | n = catalogue / index size | Key comparison | S1: each scanned element; S2: each probe of the middle entry | S1 linear; S2 logarithmic, since the range is halved each time |
| M4 | n = records in the customer–product data | Merge step (linear work per call) | Combine step of each recursive call | Depends on the recurrence: 4T(n/2)+n grows quadratically; 2T(n/2)+n grows as n log n |
| M5 | n = sales records | Record comparison/movement in the per-level sort | Combine step of each call, costing n log n | Slightly above n log n (extra log factor) |
| Report generator | n = records | Elementary operation counted by f(n) | Whole routine | Dominated by the 3n² term |

---
## (b) Iterative modules

### M1 – exact count
For i = 0, 1, …, n−2 the inner loop runs j = i+1 … n−1, i.e. (n−1−i) times.

C(n) = Σ_{i=0}^{n−2} (n−1−i) = (n−1) + (n−2) + … + 1 = **n(n−1)/2**

The count does not depend on the data (the comparison always executes), so best = worst = average.
- **Time: Θ(n²)** (n(n−1)/2 = ½n² − ½n; lower order terms vanish).
- **Space: Θ(1)** (only i, j and a counter; the products are input).
- n = 10⁶ → 499,999,500,000 comparisons.

### M2 – exact count and the team member's claim
Outer loop: i takes the values 1, 2, 4, …, 2^k while i < n. The largest k with 2^k < n is k = ⌈log₂n⌉ − 1, so the loop runs ⌈log₂n⌉ times.
For each value of i the inner loop runs i times (j = 0 … i−1), **not n times**.

A(n) = Σ_{k=0}^{⌈log₂n⌉−1} 2^k = 2^{⌈log₂n⌉} − 1   (geometric series)

Since n ≤ 2^{⌈log₂n⌉} < 2n, we get **n − 1 ≤ A(n) < 2n − 1**, hence **A(n) = Θ(n)**.

**The claim Θ(n log n) is incorrect.** It is an upper bound only (O(n log n) is true but loose) because it assumes the inner loop always runs n times; in fact it runs 1, 2, 4, … times, and the geometric sum is dominated by its last term, ≈ n. The tight bound is Θ(n). Space is Θ(1).

**Verification, n = 1024:** i = 1, 2, 4, …, 512 (i = 1024 fails i < n), i.e. 10 outer iterations.
A = 1 + 2 + 4 + … + 512 = 2¹⁰ − 1 = **1023** ≈ n. The claimed n log n = 10,240 is about 10× too large. (The program confirms 1023 by direct counting.)

---
## (c) Search S2 – backward substitution

T(n) = T(n/2) + 1, T(1) = 1. Let n = 2^k.

- T(n) = T(n/2) + 1
- = [T(n/4) + 1] + 1 = T(n/4) + 2
- = [T(n/8) + 1] + 2 = T(n/8) + 3
- … after i steps: T(n) = T(n/2^i) + i
- Stop when n/2^i = 1, i.e. i = k = log₂n:  T(n) = T(1) + log₂n

**T(n) = log₂n + 1** (exact, n a power of 2; for general n the worst case is ⌊log₂n⌋ + 1). So T(n) = Θ(log n).

| Implementation | Time | Space |
|---|---|---|
| Iterative (lo, hi, mid) | Θ(log n) | **Θ(1)** |
| Recursive | Θ(log n) | **Θ(log n)** (call stack depth log₂n + 1) |

For n = 10⁶ the worst case is ⌊log₂10⁶⌋ + 1 = 20 comparisons.

---
## (d) Master Theorem

Form T(n) = aT(n/b) + f(n); compare f(n) with n^{log_b a}.

### M4 – current design: T(n) = 4T(n/2) + n
- a = 4, b = 2, f(n) = n, n^{log₂4} = n².
- f(n) = n = O(n^{2−ε}) with ε = 1 > 0 → **Case 1**: T(n) = **Θ(n²)**.
- Exact (T(1)=1): T(n) = 2n² − n.

### M4 – redesign: T(n) = 2T(n/2) + n
- a = 2, b = 2, f(n) = n, n^{log₂2} = n.
- f(n) = Θ(n) = Θ(n^{log_b a}) → **Case 2**: T(n) = **Θ(n log n)**.
- Exact: T(n) = n log₂n + n.

### Effect of doubling the data
- Current: T(2n)/T(n) → 2(2n)²/(2n²) = **4×** (program: 4.000).
- Redesign: T(2n)/T(n) = 2(n log n + n)… ≈ 2(1 + 1/log n) → just over **2×** (program: 2.13–2.18 for n = 2¹⁰–2¹⁴, tending to 2).
So the redesign's cost grows almost linearly, whereas the current design quadruples.

### M5 – T(n) = 2T(n/2) + n log n
a = 2, b = 2, n^{log_b a} = n, f(n) = n log n.
- Case 1 (f = O(n^{1−ε})): no, f is larger than n.
- Case 2 (f = Θ(n)): no, f/n = log n → ∞.
- Case 3 (f = Ω(n^{1+ε}) for some ε > 0): no, n log n is **not polynomially larger** than n (log n < n^ε for every ε > 0 eventually), so the regularity condition is moot.
**None of the three standard cases applies.**

*Extended Master Theorem:* if f(n) = Θ(n^{log_b a} log^k n) with k ≥ 0, then T(n) = Θ(n^{log_b a} log^{k+1} n). Here k = 1 → **T(n) = Θ(n log² n)**.

*Recursion-tree check* (n = 2^m): level i has 2^i nodes, each costing (n/2^i)·log(n/2^i), so level cost = n(m − i). Summing levels i = 0 … m−1:
n·[m + (m−1) + … + 1] = n·m(m+1)/2; leaves add n·T(1) = n.
T(n) = n + n·log n(log n + 1)/2 = **Θ(n log² n)**. ✔ (program matches the closed form exactly).

---
## (e) Best, average and worst cases

### S1 – sequential scan (unsorted)
| Case | Condition | Comparisons |
|---|---|---|
| Best | Key is the first element | 1 |
| Average (successful, uniform position) | Key equally likely at any position | (n+1)/2 |
| Worst | Key is last or absent | n |

**Average with probability p that the product exists:**
- If present (prob. p): average cost = (1 + 2 + … + n)/n = (n+1)/2.
- If absent (prob. 1−p): cost = n.

A(n) = p(n+1)/2 + (1−p)n = n(1 − p/2) + p/2

For n = 1,000,000, p = 0.5: A = 0.5(1,000,001)/2 + 0.5(1,000,000) = 250,000.25 + 500,000 = **750,000.25 comparisons**. (Θ(n) in every case except the best.)

### S2 – binary search (sorted index)
| Case | Condition | Comparisons |
|---|---|---|
| Best | Key equals the first middle element | 1 |
| Average | Key at a random position (successful) | ≈ log₂n − 1 (≈ 18.9 for n = 10⁶); Θ(log n) |
| Worst | Key at the last level of the search tree, or absent | ⌊log₂n⌋ + 1 (= 20 for n = 10⁶) |

(Program, n = 1023: S1 avg 512, worst 1023; S2 best 1, avg 9.01, worst 10.)

---
## (f) Proof that f(n) = 3n² + 10n log₂n + 50 is Θ(n²)

**Definition:** f(n) = Θ(g(n)) iff ∃ c₁, c₂ > 0 and n₀ with c₁g(n) ≤ f(n) ≤ c₂g(n) for all n ≥ n₀.

**Lower bound.** All terms are non-negative for n ≥ 1, so f(n) ≥ 3n². Take **c₁ = 3**.

**Upper bound.** For n ≥ 1: log₂n ≤ n, so 10n log₂n ≤ 10n²; and 50 ≤ 50n². Therefore
f(n) ≤ 3n² + 10n² + 50n² = 63n². Take **c₂ = 63**.

So 3n² ≤ f(n) ≤ 63n² for all n ≥ **n₀ = 1**, hence **f(n) = Θ(n²)**. ∎ (Checked numerically for n = 1…100,000.)

**f(n) is not O(n).** Suppose f(n) ≤ cn for some c > 0 and all n ≥ n₀. Because f(n) ≥ 3n², this gives 3n² ≤ cn, i.e. n ≤ c/3, for all n ≥ n₀. But choosing n = max(n₀, ⌈c/3⌉ + 1) violates this. Contradiction, so no such c, n₀ exist and f(n) ∉ O(n). (Equivalently f(n)/n ≥ 3n → ∞.)

---
## (g) Scalability decision at n = 1,000,000

Window = 10 min = 600 s → at most 6 × 10¹⁰ operations.

| Module | Operations | Time | Within 10 min? |
|---|---|---|---|
| M1 duplicate detector | n(n−1)/2 ≈ 5.0 × 10¹¹ | 5,000 s ≈ **83.3 min** | **No** |
| M2 rate limiter | 2²⁰ − 1 = 1,048,575 | 10.5 ms | Yes |
| S2 binary search | 20 | 0.2 µs | Yes |
| M4 current | 2n² − n ≈ 2.0 × 10¹² | 20,000 s ≈ **5.56 h** | **No** |
| M4 redesign | n log₂n + n ≈ 2.09 × 10⁷ | 0.21 s | Yes |
| M5 analytics | n + n·log n(log n+1)/2 ≈ 2.1 × 10⁸ | 2.1 s | Yes |

Today (n = 10⁵) M1 takes 50 s and M4 (current) about 3.3 min, so both pass now but fail after the 10× growth, since quadratic cost grows 100×.

### Recommendations
1. **M1 must be redesigned.** Duplicates are exactly records with equal (title, seller), so no pairwise comparison is needed. Insert each product's key (title, seller) into a **hash table**; a key already present marks a duplicate. Cost: **Θ(n) expected time**, Θ(n) space, about 10⁶ operations (≈ 10 ms). Alternative with no extra hashing: sort by (seller, title) in Θ(n log n) and compare adjacent entries (≈ 2 × 10⁷ operations). This trades O(1) space for a huge time saving.
2. **M4 must switch to the proposed redesign** (remove replication): Θ(n²) → Θ(n log n), 5.56 h → 0.21 s, and doubling data costs ~2× instead of 4×.
3. **M2, S2, M5 need no redesign.** M2 is only Θ(n); S2 is logarithmic (use binary search in preference to S1, whose average cost of 750,000 comparisons per query is unnecessary once the index is sorted); M5 at Θ(n log² n) uses 2.1 s. M5 could be improved to Θ(n log n) by sorting once (or merging sorted halves) instead of re-sorting at every level, but this is optional.
4. Replace the report generator's quadratic part (3n²) if profiling shows it matters at scale; at n = 10⁶ it would be about 3 × 10¹² operations (≈ 8.3 h).

## Program output
See `output.txt` (generated by `Source_Code/shopsphere_audit.py`). Insert screenshots of the code and output here before submitting.
