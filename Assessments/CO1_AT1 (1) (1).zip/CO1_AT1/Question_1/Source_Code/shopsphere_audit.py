"""CSA06 CO1 AT1 - ShopSphere Scalability Audit
Empirically verifies the derivations in the report and produces the n = 1,000,000 estimates.
Run:  python3 shopsphere_audit.py
"""
import math

OPS_PER_SEC = 10**8
WINDOW_SEC = 10 * 60          # 10-minute nightly window

# ---------------- M1: duplicate detector ----------------
def m1_count(n):
    """Counts executions of the title/seller comparison (the basic operation)."""
    c = 0
    for i in range(0, n - 1):
        for j in range(i + 1, n):
            c += 1
    return c

def m1_formula(n):
    return n * (n - 1) // 2

# ---------------- M2: rate limiter ----------------
def m2_count(n):
    """Counts Audit() calls."""
    c, i = 0, 1
    while i < n:
        for j in range(0, i):
            c += 1
        i *= 2
    return c

def m2_formula(n):
    return 2 ** math.ceil(math.log2(n)) - 1

# ---------------- M3: search S1 / S2 ----------------
def s1_search(arr, key):
    comps = 0
    for x in arr:
        comps += 1
        if x == key:
            return comps
    return comps

def s2_iterative(arr, key):
    lo, hi, comps = 0, len(arr) - 1, 0
    while lo <= hi:
        mid = (lo + hi) // 2
        comps += 1
        if arr[mid] == key:
            return comps
        if key < arr[mid]:
            hi = mid - 1
        else:
            lo = mid + 1
    return comps

def s2_recurrence(n):
    """T(n)=T(n/2)+1, T(1)=1 (n power of 2)."""
    return 1 if n == 1 else s2_recurrence(n // 2) + 1

# ---------------- M4 / M5 recurrences (exact, n = 2^k) ----------------
def T_m4_current(n):  return 1 if n == 1 else 4 * T_m4_current(n // 2) + n
def T_m4_redesign(n): return 1 if n == 1 else 2 * T_m4_redesign(n // 2) + n
def T_m5(n):          return 1 if n == 1 else 2 * T_m5(n // 2) + n * math.log2(n)

def fmt_time(sec):
    if sec < 1e-3:  return f"{sec*1e6:.2f} us"
    if sec < 1:     return f"{sec*1e3:.2f} ms"
    if sec < 120:   return f"{sec:.2f} s"
    if sec < 7200:  return f"{sec/60:.1f} min"
    return f"{sec/3600:.2f} h"

def main():
    print("=== (b) M1 exact count: n(n-1)/2 ===")
    for n in (2, 5, 10, 100, 1000):
        print(f"n={n:5d}  counted={m1_count(n):8d}  formula={m1_formula(n):8d}")

    print("\n=== (b) M2 exact count: 2^ceil(log2 n) - 1 ===")
    for n in (2, 5, 8, 100, 1000, 1024):
        print(f"n={n:5d}  counted={m2_count(n):6d}  formula={m2_formula(n):6d}  "
              f"n*log2(n)={n*math.log2(n):9.1f}")
    print("n=1024 -> outer iterations i = 1,2,...,512 ->", m2_count(1024), "= 2^10 - 1")

    print("\n=== (c) S2 recurrence T(n)=log2(n)+1 ===")
    for k in range(0, 11):
        n = 2 ** k
        assert s2_recurrence(n) == k + 1
    print("T(2^k) = k + 1 verified for k = 0..10")

    print("\n=== (e) S1 and S2 best / average / worst (n = 1023, all keys present) ===")
    n = 1023
    arr = list(range(n))
    s1 = [s1_search(arr, k) for k in arr]
    s2 = [s2_iterative(arr, k) for k in arr]
    print(f"S1: best={min(s1)} avg={sum(s1)/n:.1f} (formula (n+1)/2={(n+1)/2}) worst={max(s1)}")
    print(f"S2: best={min(s2)} avg={sum(s2)/n:.3f} worst={max(s2)} (floor(log2 n)+1={int(math.log2(n))+1})")
    print(f"S1 unsuccessful search: {s1_search(arr, -1)} comparisons;  "
          f"S2 unsuccessful search worst: {max(s2_iterative(arr, k+0.5) for k in range(-1, n))}")

    N, p = 1_000_000, 0.5
    avg_s1 = p * (N + 1) / 2 + (1 - p) * N
    print(f"\nS1 average (n={N:,}, p={p}) = p(n+1)/2 + (1-p)n = {avg_s1:,.2f}")

    print("\n=== (d) M4 / M5 exact recurrences vs. closed forms ===")
    for k in (4, 8, 12):
        n = 2 ** k
        print(f"n=2^{k}: M4 current={T_m4_current(n)} (2n^2-n={2*n*n-n})  "
              f"redesign={T_m4_redesign(n)} (n log n + n={n*k+n})  "
              f"M5={T_m5(n):.0f} (n + n*k(k+1)/2={n + n*k*(k+1)/2:.0f})")
    for n in (2**10, 2**14):
        print(f"doubling n={n}: current ratio={T_m4_current(2*n)/T_m4_current(n):.3f}  "
              f"redesign ratio={T_m4_redesign(2*n)/T_m4_redesign(n):.3f}")

    print("\n=== (f) f(n)=3n^2+10n log2 n+50 : 3n^2 <= f(n) <= 63n^2 for n>=1 ===")
    f = lambda n: 3*n*n + 10*n*math.log2(n) + 50
    ok = all(3*n*n <= f(n) <= 63*n*n for n in range(1, 100001))
    print("bounds hold for n = 1..100000:", ok)
    print("f(n)/n at n=10,100,10^4,10^6:", [round(f(n)/n, 1) for n in (10, 100, 10**4, 10**6)], "-> unbounded, so f is not O(n)")

    print("\n=== (g) Scalability at n = 1,000,000  (10^8 ops/s, window = 600 s = 6e10 ops) ===")
    n = 10**6
    k = math.log2(n)
    rows = [
        ("M1 duplicate detector",   m1_formula(n)),
        ("M2 rate limiter",         m2_formula(n)),
        ("S2 binary search",        int(k) + 1),
        ("M4 current (4T(n/2)+n)",  2*n*n - n),
        ("M4 redesign (2T(n/2)+n)", n*k + n),
        ("M5 analytics",            n + n*k*(k+1)/2),
    ]
    print(f"{'Module':28s}{'Operations':>18s}{'Time':>12s}   Meets 10-min window?")
    for name, ops in rows:
        t = ops / OPS_PER_SEC
        print(f"{name:28s}{ops:18,.0f}{fmt_time(t):>12s}   {'YES' if t <= WINDOW_SEC else 'NO  <-- redesign'}")

    print("\nSame modules at today's n = 100,000:")
    n = 10**5
    for name, ops in [("M1", m1_formula(n)), ("M4 current", 2*n*n - n)]:
        print(f"{name:12s}{ops:18,.0f}{fmt_time(ops/OPS_PER_SEC):>12s}")

if __name__ == "__main__":
    main()
