# CSA06 – Design and Analysis of Algorithms
## CO1 – Assessment Tool 1: Scalability Audit of "ShopSphere"

**Student Name:** ____________  **Reg. No.:** ____________

### Structure
```
CO1_AT1/
├── Question_1/
│   ├── Source_Code/shopsphere_audit.py   # verifies every derivation, produces the n = 10^6 table
│   └── Report/Report.md, output.txt      # full solution (a)-(g) + program output
└── README.md
```

### Run
```
cd Question_1/Source_Code
python3 shopsphere_audit.py
```
No external libraries are needed (Python 3.8+).

### Headline results
| Module | Complexity | Ops at n = 10^6 | Time @ 10^8 ops/s | 10-min window |
|---|---|---|---|---|
| M1 duplicate detector | Θ(n²), space O(1) | 5.0 × 10^11 | 83.3 min | **Fails** |
| M2 rate limiter | Θ(n) (not Θ(n log n)) | 1,048,575 | 10.5 ms | OK |
| S2 binary search | Θ(log n) | 20 | 0.2 µs | OK |
| M4 current | Θ(n²) | 2.0 × 10^12 | 5.56 h | **Fails** |
| M4 redesign | Θ(n log n) | 2.09 × 10^7 | 0.21 s | OK |
| M5 analytics | Θ(n log² n) | 2.1 × 10^8 | 2.1 s | OK |
