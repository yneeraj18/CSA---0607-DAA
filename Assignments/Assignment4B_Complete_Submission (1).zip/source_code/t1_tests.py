"""Boundary and validation tests for Task 1."""
import random
from task1_wordwrap import word_wrap, greedy_wrap, brute_force_penalty, TEXT, print_layout


def show(title, words, width):
    print(f"--- {title}: words={words} M={width}")
    try:
        total, lines, *_ = word_wrap(words, width)
        for k, ln in enumerate(lines, 1):
            print(f"    line {k}: '{' '.join(ln['words'])}' used={ln['used']} unused={ln['unused']} penalty={ln['penalty']}")
        print(f"    total penalty = {total}")
    except ValueError as e:
        print(f"    ValueError raised: {e}")


if __name__ == "__main__":
    # B1 - the designed boundary case: a line that fills the width EXACTLY.
    show("B1 exact fit (aaa+bb = 6 = M)", ["aaa", "bb", "cc"], 6)
    show("B2 everything fits one line (final line is free)", ["aa", "bb", "cc"], 20)
    show("B3 single word equal to M", ["abcdef"], 6)
    show("B4 word longer than M (invalid)", ["abc", "abcdefgh"], 5)
    show("B5 empty text", [], 10)
    show("B6 every word needs its own line", ["abcd", "efgh", "ijkl"], 5)
    # Cross-check against exhaustive enumeration on random small inputs
    random.seed(2026)
    bad, trials = 0, 300
    for _ in range(trials):
        n = random.randint(1, 11)
        words = ["x" * random.randint(1, 6) for _ in range(n)]
        width = random.randint(6, 16)
        dp_val = word_wrap(words, width)[0]
        ref = brute_force_penalty(words, width)
        if dp_val != ref:
            bad += 1
    print(f"--- randomized cross-check DP vs exhaustive: {trials} cases, mismatches = {bad}")
    # DP versus greedy on the report text
    words = TEXT.split()
    for w in (26, 30, 36, 45):
        d = word_wrap(words, w)[0]
        g = greedy_wrap(words, w)[0]
        print(f"--- M={w}: DP penalty={d}  greedy first-fit penalty={g}")
    # Where first-fit greedy is NOT optimal (lengths 6,1,5,5,4 with M = 10)
    ex = ["parcel", "a", "truck", "depot", "fuel"]
    d_total, d_lines, *_ = word_wrap(ex, 10)
    g_total, g_lines = greedy_wrap(ex, 10)
    print(f"--- DP beats greedy: words={ex} M=10")
    print("    DP    :", [" ".join(l["words"]) for l in d_lines], "penalty", d_total)
    print("    greedy:", [" ".join(l) for l in g_lines], "penalty", g_total)
