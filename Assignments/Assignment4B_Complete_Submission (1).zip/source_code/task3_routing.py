"""Task 3 - Routing engine: Dijkstra, Bellman-Ford, Floyd and Warshall.

Graph model: directed weighted graph given as an edge list [(u, v, w)].
Vertices: Hub, A, B, C, D, E, F, G  (8)   Edges: 12 (13 / 14 in the modified networks)
"""
import heapq

INF = float("inf")
VERTICES = ["Hub", "A", "B", "C", "D", "E", "F", "G"]
BASE_EDGES = [
    ("Hub", "A", 2), ("Hub", "B", 5), ("Hub", "C", 9),
    ("A", "C", 4), ("A", "D", 3), ("B", "D", 7),
    ("C", "E", 2), ("D", "E", 6), ("D", "F", 8),
    ("E", "F", 3), ("E", "G", 7), ("F", "G", 1),
]
NEG_EDGE = ("B", "A", -4)               # Stage B: a cheaper road from B to A (e.g. a subsidised toll rebate)
CYCLE_EDGE = ("D", "B", -2)             # Stage C: closes B -> A -> D -> B  with weight -4+3-2 = -3


def adjacency(vertices, edges):
    adj = {v: [] for v in vertices}
    for u, v, w in edges:
        adj[u].append((v, w))
    return adj


def dijkstra(vertices, edges, source):
    """Classic Dijkstra: a vertex is FINAL once popped.  Returns dist, pred, order, ops."""
    adj = adjacency(vertices, edges)
    dist = {v: INF for v in vertices}
    pred = {v: None for v in vertices}
    dist[source] = 0
    heap, done, order = [(0, source)], set(), []
    ops = {"pops": 0, "relaxations": 0, "improvements": 0}
    log = []
    while heap:
        d, u = heapq.heappop(heap)
        ops["pops"] += 1
        if u in done:
            continue
        done.add(u)
        order.append((u, d))
        for v, w in adj[u]:
            ops["relaxations"] += 1
            if v in done:
                if d + w < dist[v]:
                    log.append(f"   !! edge {u}->{v} ({w}) would improve FINALISED vertex {v}: {dist[v]} -> {d+w}, ignored")
                continue
            if d + w < dist[v]:
                dist[v], pred[v] = d + w, u
                ops["improvements"] += 1
                heapq.heappush(heap, (dist[v], v))
    return dist, pred, order, ops, log


def path_to(pred, source, target):
    path, cur = [], target
    while cur is not None:
        path.append(cur)
        cur = pred[cur]
    path.reverse()
    return path if path and path[0] == source else None


def bellman_ford(vertices, edges, source):
    """Returns dist, pred, passes_log, cycle_info, ops.
    cycle_info = None, or (cycle_vertices, affected_vertices)."""
    dist = {v: INF for v in vertices}
    pred = {v: None for v in vertices}
    dist[source] = 0
    ops = {"relaxations": 0, "improvements": 0}
    passes = []
    n = len(vertices)
    for p in range(1, n):
        changed = []
        for u, v, w in edges:
            ops["relaxations"] += 1
            if dist[u] != INF and dist[u] + w < dist[v]:
                dist[v], pred[v] = dist[u] + w, u
                ops["improvements"] += 1
                changed.append(f"{u}->{v}")
        passes.append((p, dict(dist), changed))
        if not changed:
            break
    # n-th pass: any further improvement proves a reachable negative cycle
    witness = None
    for u, v, w in edges:
        ops["relaxations"] += 1
        if dist[u] != INF and dist[u] + w < dist[v]:
            witness = (u, v, w)
            pred[v] = u
            break
    if witness is None:
        return dist, pred, passes, None, ops
    x = witness[1]
    for _ in range(n):                      # walk back n steps -> guaranteed to be ON the cycle
        x = pred[x]
    cycle, cur = [x], pred[x]
    while cur != x:
        cycle.append(cur)
        cur = pred[cur]
    cycle.reverse()
    adj = adjacency(vertices, edges)
    affected, stack = set(), list(cycle)    # everything reachable from the cycle has no finite shortest path
    while stack:
        a = stack.pop()
        if a in affected:
            continue
        affected.add(a)
        stack.extend(b for b, _ in adj[a])
    return dist, pred, passes, (cycle, affected, witness), ops


def floyd(vertices, edges):
    n = len(vertices)
    idx = {v: i for i, v in enumerate(vertices)}
    d = [[INF] * n for _ in range(n)]
    nxt = [[None] * n for _ in range(n)]
    for i in range(n):
        d[i][i] = 0
    for u, v, w in edges:
        d[idx[u]][idx[v]] = min(d[idx[u]][idx[v]], w)
        nxt[idx[u]][idx[v]] = idx[v]
    ops = {"inner_updates": 0, "improvements": 0}
    for k in range(n):
        for i in range(n):
            if d[i][k] == INF:
                continue
            for j in range(n):
                ops["inner_updates"] += 1
                if d[i][k] + d[k][j] < d[i][j]:
                    d[i][j] = d[i][k] + d[k][j]
                    nxt[i][j] = nxt[i][k]
                    ops["improvements"] += 1
    neg_cycle = any(d[i][i] < 0 for i in range(n))
    return d, nxt, neg_cycle, ops


def warshall(vertices, edges):
    n = len(vertices)
    idx = {v: i for i, v in enumerate(vertices)}
    r = [[False] * n for _ in range(n)]
    for i in range(n):
        r[i][i] = True
    for u, v, _ in edges:
        r[idx[u]][idx[v]] = True
    for k in range(n):
        for i in range(n):
            if r[i][k]:
                for j in range(n):
                    if r[k][j]:
                        r[i][j] = True
    return r


def floyd_path(vertices, nxt, i, j):
    if nxt[i][j] is None and i != j:
        return None
    p = [vertices[i]]
    while i != j:
        i = nxt[i][j]
        p.append(vertices[i])
    return p


# ------------------------------ presentation ------------------------------
def fmt(x):
    return "INF" if x == INF else ("-INF" if x == -INF else str(x))


def show_sssp(title, dist, pred, source):
    print(title)
    print(f"  {'Vertex':<7}{'Distance':>9}  {'Pred':<5} Path")
    for v in VERTICES:
        p = path_to(pred, source, v)
        print(f"  {v:<7}{fmt(dist[v]):>9}  {str(pred[v]):<5} {' -> '.join(p) if p else '-'}")


def show_matrix(title, labels, m, cell=lambda x: x):
    print(title)
    print("       " + "".join(f"{l:>5}" for l in labels))
    for l, row in zip(labels, m):
        print(f"  {l:<5}" + "".join(f"{cell(x):>5}" for x in row))


def stage_a():
    dist, pred, order, ops, log = dijkstra(VERTICES, BASE_EDGES, "Hub")
    print("Stage A - Dijkstra on the normal network, source = Hub")
    print("  Order in which vertices become FINAL:", ", ".join(f"{v}({d})" for v, d in order))
    show_sssp("  Result:", dist, pred, "Hub")
    print("  ops:", ops)
    return dist, pred


def stage_b():
    edges = BASE_EDGES + [NEG_EDGE]
    print("Stage B - network with negative edge B->A (-4)")
    dist, pred, order, ops, log = dijkstra(VERTICES, edges, "Hub")
    print("  Dijkstra finalisation order:", ", ".join(f"{v}({d})" for v, d in order))
    for line in log:
        print(line)
    show_sssp("  Dijkstra result on modified graph:", dist, pred, "Hub")
    bd, bp, passes, cyc, bops = bellman_ford(VERTICES, edges, "Hub")
    print("\n  Bellman-Ford pass-by-pass distances (after each pass):")
    print("  pass | " + " ".join(f"{v:>4}" for v in VERTICES) + " | edges that improved")
    for p, d, ch in passes:
        print(f"  {p:>4} | " + " ".join(f"{fmt(d[v]):>4}" for v in VERTICES) + " | " + ", ".join(ch))
    show_sssp("\n  Bellman-Ford result:", bd, bp, "Hub")
    print("  ops:", bops, "negative cycle:", cyc is not None)
    print("\n  Difference (Dijkstra - Bellman-Ford):")
    for v in VERTICES:
        flag = "  <-- WRONG" if dist[v] != bd[v] else ""
        print(f"   {v:<4} Dijkstra={fmt(dist[v]):>3}  BellmanFord={fmt(bd[v]):>3}{flag}")
    return dist, bd


def stage_c():
    edges = BASE_EDGES + [NEG_EDGE, CYCLE_EDGE]
    print("Stage C - network with the extra edge D->B (-2): cycle B->A->D->B = -4+3-2 = -3")
    dj, dp, order, _, _ = dijkstra(VERTICES, edges, "Hub")
    print("  Dijkstra (no cycle awareness) returns:", {v: fmt(dj[v]) for v in VERTICES})
    bd, bp, passes, cyc, ops = bellman_ford(VERTICES, edges, "Hub")
    print("  Bellman-Ford passes executed before the check pass:", len(passes))
    if cyc:
        cycle, affected, witness = cyc
        print(f"  NEGATIVE CYCLE DETECTED: witness edge {witness[0]}->{witness[1]} still relaxes in pass |V| = {len(VERTICES)}")
        print("  Cycle:", " -> ".join(cycle + [cycle[0]]))
        weights = {(u, v): w for u, v, w in edges}
        tot = sum(weights[(cycle[i], cycle[(i + 1) % len(cycle)])] for i in range(len(cycle)))
        print("  Cycle weight:", tot)
        print("  Vertices whose shortest distance is -infinity:", sorted(affected, key=VERTICES.index))
    return cyc


def stage_d():
    edges = BASE_EDGES + [NEG_EDGE]
    d, nxt, neg, ops = floyd(VERTICES, edges)
    print("Stage D - Floyd all-pairs shortest path (network of Stage B, no negative cycle)")
    show_matrix("  Distance matrix:", VERTICES, d, fmt)
    print("  ops:", ops, "| negative cycle found (some d[i][i] < 0):", neg)
    r = warshall(VERTICES, edges)
    show_matrix("  Warshall reachability matrix (1 = reachable):", VERTICES, r, lambda x: 1 if x else 0)
    unreachable = [(VERTICES[i], VERTICES[j]) for i in range(8) for j in range(8) if not r[i][j]]
    print("  Number of unreachable ordered pairs:", len(unreachable))
    i, j = VERTICES.index("Hub"), VERTICES.index("G")
    print("  Floyd route Hub->G:", " -> ".join(floyd_path(VERTICES, nxt, i, j)), " cost", d[i][j])
    # Floyd on the cycle graph
    dc, _, negc, _ = floyd(VERTICES, edges + [CYCLE_EDGE])
    print("  Floyd on the Stage C network: negative diagonal entries ->",
          [VERTICES[i] for i in range(8) if dc[i][i] < 0], "(cycle reported)")
    return d, r


if __name__ == "__main__":
    stage_a(); print()
    stage_b(); print()
    stage_c(); print()
    stage_d()
