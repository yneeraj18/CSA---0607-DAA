"""Task 6 - Travelling salesperson by Held-Karp dynamic programming.

Locations 0..n ; location 0 is the distribution hub, 1..n are delivery locations.
State  dp[S][j] : minimum cost of a path that starts at the hub, visits exactly the delivery
                  locations in set S (a bitmask over 1..n) and ENDS at j (j in S).
Base   dp[{j}][j] = cost[0][j]
Step   dp[S][j] = min over i in S\\{j} of dp[S\\{j}][i] + cost[i][j]
Answer min over j of dp[ALL][j] + cost[j][0]        (return to the hub)
parent[S][j] stores the best predecessor i, which rebuilds the route.
"""
import itertools
import random
import time
import tracemalloc

INF = float("inf")
NAMES = ["Hub", "A", "B", "C", "D", "E", "F", "G"]
COST = [  # symmetric travel costs (minutes): Hub + 7 delivery locations
    [0, 12, 10, 19, 8, 14, 17, 9],
    [12, 0, 3, 7, 2, 11, 6, 15],
    [10, 3, 0, 6, 20, 5, 12, 8],
    [19, 7, 6, 0, 4, 9, 13, 10],
    [8, 2, 20, 4, 0, 16, 7, 11],
    [14, 11, 5, 9, 16, 0, 4, 6],
    [17, 6, 12, 13, 7, 4, 0, 18],
    [9, 15, 8, 10, 11, 6, 18, 0],
]


def check_matrix(cost):
    n = len(cost)
    if n < 2 or any(len(r) != n for r in cost):
        raise ValueError("cost matrix must be square with at least a hub and one location")
    if any(cost[i][i] != 0 for i in range(n)) or any(c < 0 for r in cost for c in r):
        raise ValueError("diagonal must be 0 and costs non-negative")


def held_karp(cost):
    """Returns (best_cost, route[0..], states_evaluated, transitions, dp_entries)."""
    check_matrix(cost)
    m = len(cost) - 1                      # delivery locations
    if m == 1:
        return cost[0][1] + cost[1][0], [0, 1, 0], 1, 0, 1
    size = 1 << m
    dp = [[INF] * m for _ in range(size)]
    parent = [[-1] * m for _ in range(size)]
    states = transitions = 0
    for j in range(m):
        dp[1 << j][j] = cost[0][j + 1]
        states += 1
    for S in range(1, size):
        for j in range(m):
            if not S >> j & 1 or S == 1 << j:
                continue
            states += 1
            prevS = S ^ (1 << j)
            best, arg = INF, -1
            for i in range(m):
                if prevS >> i & 1:
                    transitions += 1
                    v = dp[prevS][i] + cost[i + 1][j + 1]
                    if v < best:
                        best, arg = v, i
            dp[S][j], parent[S][j] = best, arg
    full = size - 1
    best, last = INF, -1
    for j in range(m):
        v = dp[full][j] + cost[j + 1][0]
        if v < best:
            best, last = v, j
    route, S, j = [], full, last
    while j != -1:
        route.append(j + 1)
        pj = parent[S][j]
        S ^= 1 << j
        j = pj
    route.reverse()
    return best, [0] + route + [0], states, transitions, size * m


def brute_force(cost):
    m = len(cost) - 1
    best, best_route, count = INF, None, 0
    for perm in itertools.permutations(range(1, m + 1)):
        count += 1
        c = cost[0][perm[0]] + sum(cost[perm[k]][perm[k + 1]] for k in range(m - 1)) + cost[perm[-1]][0]
        if c < best:
            best, best_route = c, [0, *perm, 0]
    return best, best_route, count, [
        (cost[0][p[0]] + sum(cost[p[k]][p[k + 1]] for k in range(m - 1)) + cost[p[-1]][0], p)
        for p in itertools.permutations(range(1, m + 1))]


def sub_matrix(cost, k):
    keep = list(range(k + 1))
    return [[cost[i][j] for j in keep] for i in keep]


def random_matrix(m, seed=1):
    rnd = random.Random(seed)
    n = m + 1
    c = [[0] * n for _ in range(n)]
    for i in range(n):
        for j in range(i + 1, n):
            c[i][j] = c[j][i] = rnd.randint(5, 60)
    return c


def name_route(route, names=NAMES):
    return " -> ".join(names[i] for i in route)


def growth_table(max_m=15):
    rows = []
    for m in range(4, max_m + 1):
        c = random_matrix(m, seed=m)
        tracemalloc.start()
        t0 = time.perf_counter()
        best, route, states, trans, entries = held_karp(c)
        dt = time.perf_counter() - t0
        peak = tracemalloc.get_traced_memory()[1]
        tracemalloc.stop()
        rows.append((m, states, trans, entries, dt, peak, best))
    return rows


if __name__ == "__main__":
    best, route, states, trans, entries = held_karp(COST)
    print("Cost matrix (minutes):")
    print("      " + "".join(f"{n:>5}" for n in NAMES))
    for n, r in zip(NAMES, COST):
        print(f"  {n:<4}" + "".join(f"{x:>5}" for x in r))
    print(f"\nMinimum travel cost = {best}")
    print("Optimal route:", name_route(route))
    print("Visit order:", ", ".join(NAMES[i] for i in route[1:-1]))
    legs = [(NAMES[a], NAMES[b], COST[a][b]) for a, b in zip(route, route[1:])]
    print("Legs:", legs, "sum =", sum(l[2] for l in legs))
    print(f"States evaluated = {states}, transitions = {trans}")
    print("\n--- 6.4 validation: hub + 4 locations ---")
    small = sub_matrix(COST, 4)
    b, r, cnt, allr = brute_force(small)
    d_best, d_route, *_ = held_karp(small)
    print(f"Exhaustive: {cnt} permutations; every route cost:")
    for c, p in sorted(allr):
        print("   ", name_route([0, *p, 0]), "=", c)
    print("Exhaustive optimum:", b, name_route(r), "| DP optimum:", d_best, name_route(d_route))
    print("\n--- 6.5 state-space growth (random symmetric costs, seed = n) ---")
    print(f"{'n':>3} {'DP states':>10} {'transitions':>12} {'dp table entries':>17} {'time (s)':>9} {'peak mem (KB)':>14} {'n! routes':>16}")
    import math
    for m, st, tr, en, dt, peak, bst in growth_table():
        print(f"{m:>3} {st:>10} {tr:>12} {en:>17} {dt:>9.4f} {peak/1024:>14.0f} {math.factorial(m):>16}")
    print("\n--- 6.6 n = 200 ---")
    n = 200
    print("2^200 subsets      =", f"{2**n:.3e}")
    print("n*2^n states       =", f"{n * 2**n:.3e}")
    print("n^2*2^n operations =", f"{n*n*2**n:.3e}")
    print("memory at 8 bytes/entry ~", f"{n*2**n*8:.3e} bytes")
