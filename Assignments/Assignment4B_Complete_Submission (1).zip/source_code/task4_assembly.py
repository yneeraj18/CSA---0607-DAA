"""Task 4 - Two-line assembly scheduling by Dynamic Programming.

Inputs
  a[i][j]  processing time of station j on line i   (i = 0, 1 ; j = 0..n-1)
  t[i][j]  time to move from line i, AFTER station j, to the other line before station j+1  (j = 0..n-2)
  e[i]     entry time onto line i          x[i]  exit time from line i
State    f[i][j] = fastest time to finish station j when the product is ON line i at station j
Base     f[i][0] = e[i] + a[i][0]
Recurrence  f[i][j] = a[i][j] + min( f[i][j-1]               (stay),
                                      f[1-i][j-1] + t[1-i][j-1] (transfer) )
Answer   F = min( f[0][n-1] + x[0], f[1][n-1] + x[1] )
prev[i][j] stores which line the product came from -> used to rebuild the route.
"""
import itertools


def validate(a, t, e, x):
    n = len(a[0])
    if n == 0 or len(a[1]) != n:
        raise ValueError("both lines need the same, non-zero number of stations")
    if len(t[0]) != n - 1 or len(t[1]) != n - 1:
        raise ValueError("transfer lists need n-1 entries")
    for arr in (a[0], a[1], t[0], t[1], e, x):
        if any(v < 0 for v in arr):
            raise ValueError("times must be non-negative")


def assembly_dp(a, t, e, x):
    validate(a, t, e, x)
    n = len(a[0])
    f = [[0] * n for _ in range(2)]
    prev = [[None] * n for _ in range(2)]
    trace = []                          # one row per station j >= 1
    for i in (0, 1):
        f[i][0] = e[i] + a[i][0]
    for j in range(1, n):
        row = {"station": j + 1}
        for i in (0, 1):
            stay = f[i][j - 1] + a[i][j]
            move = f[1 - i][j - 1] + t[1 - i][j - 1] + a[i][j]
            if stay <= move:                     # tie -> prefer staying (fewer transfers)
                f[i][j], prev[i][j], pick = stay, i, "stay"
            else:
                f[i][j], prev[i][j], pick = move, 1 - i, "transfer"
            row[f"stay{i+1}"], row[f"move{i+1}"], row[f"pick{i+1}"] = stay, move, pick
        trace.append(row)
    finish = [f[0][n - 1] + x[0], f[1][n - 1] + x[1]]
    last = 0 if finish[0] <= finish[1] else 1
    best = finish[last]
    route = [0] * n
    route[n - 1] = last
    for j in range(n - 1, 0, -1):
        route[j - 1] = prev[route[j]][j]
    transfers = [(j + 1, route[j] + 1, route[j + 1] + 1) for j in range(n - 1) if route[j] != route[j + 1]]
    return {"best": best, "route": route, "transfers": transfers, "f": f, "prev": prev,
            "trace": trace, "finish": finish, "ops": {"cells": 2 * n, "comparisons": 2 * (n - 1) + 1}}


def brute_force(a, t, e, x):
    n = len(a[0])
    best = float("inf")
    for choice in itertools.product((0, 1), repeat=n):
        cost = e[choice[0]] + a[choice[0]][0]
        for j in range(1, n):
            if choice[j] != choice[j - 1]:
                cost += t[choice[j - 1]][j - 1]
            cost += a[choice[j]][j]
        best = min(best, cost + x[choice[-1]])
    return best


# ------------------------------ presentation ------------------------------
def print_route(res):
    route = res["route"]
    print("  Entry")
    for j, i in enumerate(route):
        mark = ""
        if j > 0 and route[j - 1] != i:
            mark = f"  Transfer (Line {route[j-1]+1} -> Line {i+1})"
        print("   |" + mark if mark else "   |")
        print(f"  Line {i+1} - Station {j+1}")
    print("   |\n  Exit")
    print(f"  Minimum Production Time = {res['best']}")
    print("  Transfer points:", [f"after station {s}: Line {a}->Line {b}" for s, a, b in res["transfers"]] or "none")


def print_trace(res, f_first):
    print(f"  {'Stn':<4}{'L1 stay':>8}{'L1 xfer':>9}{'Sel':>9}{'L2 stay':>9}{'L2 xfer':>9}{'Sel':>9}{'f1':>5}{'f2':>5}")
    print(f"  {1:<4}{'-':>8}{'-':>9}{'entry':>9}{'-':>9}{'-':>9}{'entry':>9}{f_first[0]:>5}{f_first[1]:>5}")
    for k, r in enumerate(res["trace"]):
        j = k + 1
        print(f"  {r['station']:<4}{r['stay1']:>8}{r['move1']:>9}{r['pick1']:>9}{r['stay2']:>9}{r['move2']:>9}{r['pick2']:>9}"
              f"{res['f'][0][j]:>5}{res['f'][1][j]:>5}")
    print(f"  Exit: f1+x1 = {res['finish'][0]}, f2+x2 = {res['finish'][1]}  ->  min = {res['best']}")


A = [[6, 8, 4, 5, 9, 3], [7, 4, 7, 3, 6, 5]]
T = [[2, 3, 1, 4, 2], [3, 1, 2, 2, 3]]
E = [3, 2]
X = [2, 4]


def run(label, a, t, e, x, show_trace=True):
    res = assembly_dp(a, t, e, x)
    print(f"--- {label}")
    print("  a1 =", a[0], " a2 =", a[1])
    print("  t1 =", t[0], " t2 =", t[1], " e =", e, " x =", x)
    if show_trace:
        print_trace(res, (res["f"][0][0], res["f"][1][0]))
    print_route(res)
    print("  Brute-force check (2^n lines):", brute_force(a, t, e, x))
    return res


def experiments():
    import copy
    print("=== Task 4.3 : transfer t2 after station 2 raised 1 -> 15 ===")
    t = copy.deepcopy(T)
    t[1][1] = 15
    r3 = run("MODIFIED TRANSFER", A, t, E, X)
    print()
    print("=== Task 4.4 : station 4 on Line 2 slowed 3 -> 15 ===")
    a = copy.deepcopy(A)
    a[1][3] = 15
    r4 = run("MACHINE DISRUPTION", a, T, E, X)
    return r3, r4


if __name__ == "__main__":
    run("BASE CASE", A, T, E, X)
    print()
    experiments()
