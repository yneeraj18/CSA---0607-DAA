"""Task 2 - Greedy (fractional) vs Dynamic Programming (0/1) knapsack.

Solution A  fractional knapsack, greedy on value/weight (optimal for the fractional formulation)
Solution B  0/1 knapsack, bottom-up DP over (item index, capacity), with item reconstruction
Also: greedy_01 = the SAME value/weight intuition applied to 0/1 items (take whole items in ratio
order while they fit) - this is what is shown to fail in 2.2.
Every routine counts its own basic operations so that work is compared without timing.
"""
import random


class Item:
    def __init__(self, ident, weight, value):
        if weight <= 0 or value < 0:
            raise ValueError("weight must be > 0 and value >= 0")
        self.ident, self.weight, self.value = ident, weight, value

    @property
    def ratio(self):
        return self.value / self.weight


def fractional_greedy(items, capacity):
    """Returns (value, picks[(id, fraction, gained)], ops)."""
    ops = {"comparisons": 0, "steps": 0}
    order = sorted(items, key=lambda it: -it.ratio)
    n = len(items)
    ops["comparisons"] = int(n * max(n.bit_length(), 1))      # ~ n log n sort model
    left, total, picks = capacity, 0.0, []
    for it in order:
        ops["steps"] += 1
        if left <= 0:
            break
        take = min(1.0, left / it.weight)
        gained = take * it.value
        picks.append((it.ident, take, gained, it.ratio, left))
        total += gained
        left -= take * it.weight
    return total, picks, ops


def greedy_01(items, capacity):
    """Value/weight greedy on 0/1 items: take an item whole if it still fits, else skip it."""
    ops = {"comparisons": 0, "steps": 0}
    order = sorted(items, key=lambda it: -it.ratio)
    n = len(items)
    ops["comparisons"] = int(n * max(n.bit_length(), 1))
    left, total, log = capacity, 0, []
    for it in order:
        ops["steps"] += 1
        if it.weight <= left:
            left -= it.weight
            total += it.value
            log.append((it.ident, "TAKE", it.ratio, left))
        else:
            log.append((it.ident, "SKIP (does not fit)", it.ratio, left))
    return total, log, ops


def knapsack_dp(items, capacity):
    """Returns (value, chosen_ids, table, ops).  table[i][c] = best value using first i items, capacity c."""
    n = len(items)
    table = [[0] * (capacity + 1) for _ in range(n + 1)]
    ops = {"cells": 0, "comparisons": 0}
    for i in range(1, n + 1):
        it = items[i - 1]
        for c in range(capacity + 1):
            ops["cells"] += 1
            best = table[i - 1][c]
            if it.weight <= c:
                ops["comparisons"] += 1
                best = max(best, table[i - 1][c - it.weight] + it.value)
            table[i][c] = best
    chosen, c = [], capacity
    for i in range(n, 0, -1):
        if table[i][c] != table[i - 1][c]:
            chosen.append(items[i - 1].ident)
            c -= items[i - 1].weight
    chosen.reverse()
    return table[n][capacity], chosen, table, ops


def knapsack_dp_two_rows(items, capacity):
    """Value only, O(W) memory - shown to quantify the memory/reconstruction trade-off."""
    row = [0] * (capacity + 1)
    for it in items:
        for c in range(capacity, it.weight - 1, -1):
            row[c] = max(row[c], row[c - it.weight] + it.value)
    return row[capacity]


def brute_force_01(items, capacity):
    best = 0
    for mask in range(1 << len(items)):
        w = v = 0
        for k, it in enumerate(items):
            if mask >> k & 1:
                w += it.weight
                v += it.value
        if w <= capacity and v > best:
            best = v
    return best


def make(rows):
    return [Item(*r) for r in rows]


# Datasets -----------------------------------------------------------------
NORMAL_ROWS = [("P1", 10, 60), ("P2", 20, 100), ("P3", 30, 120), ("P4", 15, 90), ("P5", 5, 40)]
NORMAL_CAP = 60          # fractional greedy ends with a fraction of P3
EXACT_CAP = 30           # whole items P5+P1+P4 fill this capacity exactly
BREAK_ROWS = [("B1", 6, 30), ("B2", 5, 24), ("B3", 5, 24), ("B4", 4, 16)]   # own counter-example
BREAK_CAP = 10


def run_normal():
    items = make(NORMAL_ROWS)
    print("Dataset (Item, Weight, Value, Value/Weight):")
    for it in items:
        print(f"  {it.ident}  w={it.weight:<3} v={it.value:<4} v/w={it.ratio:.2f}")
    print(f"Capacity = {NORMAL_CAP}")
    val, picks, fo = fractional_greedy(items, NORMAL_CAP)
    print("\nSolution A - fractional greedy decision sequence")
    print(f"  {'Step':<4}{'Item':<6}{'v/w':>6}{'capacity left':>15}{'fraction':>10}{'value gained':>14}")
    for k, (i, f, g, r, left) in enumerate(picks, 1):
        print(f"  {k:<4}{i:<6}{r:>6.2f}{left:>15.1f}{f:>10.2f}{g:>14.1f}")
    print(f"  Fractional optimum = {val:.1f}   operations = {fo}")
    v01, chosen, table, do = knapsack_dp(items, NORMAL_CAP)
    g01, glog, go = greedy_01(items, NORMAL_CAP)
    print(f"\nSolution B - 0/1 DP optimum = {v01}, items = {chosen}, work = {do}")
    print(f"  0/1 greedy (same ratio rule) = {g01}, decisions = {[(a,b) for a,b,_,_ in glog]}")
    items_b = make(NORMAL_ROWS)
    print(f"\nVariant 2.1b - capacity {EXACT_CAP}: whole high-ratio items fill the vehicle exactly")
    val, picks, fo = fractional_greedy(items_b, EXACT_CAP)
    print("  greedy picks:", [(i, round(f, 2)) for i, f, *_ in picks], "value =", val)
    v01, chosen, _, _ = knapsack_dp(items_b, EXACT_CAP)
    print("  0/1 DP optimum =", v01, "items =", chosen, "| 0/1 greedy =", greedy_01(items_b, EXACT_CAP)[0])
    return items


def run_break():
    items = make(BREAK_ROWS)
    print("Own counter-example (Item, Weight, Value, Value/Weight):")
    for it in items:
        print(f"  {it.ident}  w={it.weight:<3} v={it.value:<4} v/w={it.ratio:.2f}")
    print(f"Capacity = {BREAK_CAP}")
    g, log, go = greedy_01(items, BREAK_CAP)
    print("\nGreedy (ratio order) decision sequence on 0/1 items:")
    for k, (i, act, r, left) in enumerate(log, 1):
        print(f"  step {k}: {i} v/w={r:.2f} -> {act:<22} capacity left = {left}")
    print(f"  Greedy 0/1 value = {g}")
    v, chosen, table, do = knapsack_dp(items, BREAK_CAP)
    print(f"DP optimum = {v}, chosen items = {chosen}")
    print(f"Brute-force check over all {2**len(items)} subsets = {brute_force_01(items, BREAK_CAP)}")
    fv, picks, fo = fractional_greedy(items, BREAK_CAP)
    print(f"(Fractional optimum, an upper bound = {fv:.1f})")
    print("\nDP table (rows = items considered, columns = capacity 0..%d):" % BREAK_CAP)
    print("      " + " ".join(f"{c:>3}" for c in range(BREAK_CAP + 1)))
    for i, row in enumerate(table):
        lab = "none" if i == 0 else items[i - 1].ident
        print(f"  {lab:<4}" + " ".join(f"{x:>3}" for x in row))
    return items


def compare_scaling():
    random.seed(7)
    print(f"{'n':>5} {'W':>8} | {'greedy ops (cmp+steps)':>24} {'DP cells':>12} {'DP cmp':>10} | {'greedy mem':>10} {'DP table cells':>15} {'DP 2-row':>9}")
    for n, W in [(10, 50), (50, 500), (100, 1000), (200, 5000), (200, 50000), (400, 100000)]:
        items = [Item(f"i{k}", random.randint(1, W // 4 + 1), random.randint(1, 100)) for k in range(n)]
        _, _, go = fractional_greedy(items, W)
        _, _, _, do = knapsack_dp(items, W) if n * W <= 8_000_000 else (0, 0, 0, {"cells": (n) * (W + 1), "comparisons": None})
        gm = n
        print(f"{n:>5} {W:>8} | {go['comparisons'] + go['steps']:>24} {do['cells']:>12} {str(do['comparisons']):>10} | {gm:>10} {(n+1)*(W+1):>15} {W+1:>9}")


def quality_study(trials=2000):
    random.seed(11)
    opt_hits, ratios = 0, []
    worst = (1.0, None)
    for _ in range(trials):
        n = random.randint(4, 10)
        W = random.randint(10, 40)
        items = [Item(f"i{k}", random.randint(1, 15), random.randint(1, 60)) for k in range(n)]
        g = greedy_01(items, W)[0]
        o = knapsack_dp(items, W)[0]
        r = g / o if o else 1.0
        ratios.append(r)
        if g == o:
            opt_hits += 1
        if r < worst[0]:
            worst = (r, [(i.weight, i.value) for i in items], W, g, o)
    avg = sum(ratios) / len(ratios)
    print(f"Random 0/1 instances: {trials}; greedy optimal in {opt_hits} ({100*opt_hits/trials:.1f}%); "
          f"mean value ratio greedy/optimum = {avg:.4f}; worst ratio found = {worst[0]:.3f}")
    imp = []
    random.seed(11)
    for _ in range(trials):
        n = random.randint(4, 10)
        W = random.randint(10, 40)
        items = [Item(f"i{k}", random.randint(1, 15), random.randint(1, 60)) for k in range(n)]
        o = knapsack_dp(items, W)[0]
        h = max(greedy_01(items, W)[0], max([i.value for i in items if i.weight <= W], default=0))
        imp.append(h / o if o else 1.0)
    print(f"Greedy + best single item: optimal in {sum(1 for r in imp if r == 1.0)}, mean ratio {sum(imp)/len(imp):.4f}, worst ratio {min(imp):.3f}")
    print(f"  worst instance: W={worst[2]} items(w,v)={worst[1]} greedy={worst[3]} optimum={worst[4]}")
    # adversarial family: greedy ratio can be made arbitrarily bad
    print("Adversarial family: items (w=1,v=2) and (w=K,v=2K-1), capacity K ->")
    for K in (10, 100, 1000, 10000):
        items = [Item("small", 1, 2), Item("big", K, 2 * K - 1)]
        g = greedy_01(items, K)[0]
        o = brute_force_01(items, K)
        print(f"  K={K:>6}: greedy={g:>6} optimum={o:>6} ratio={g/o:.5f}")


if __name__ == "__main__":
    print("=== 2.1 NORMAL CASE ==="); run_normal()
    print("\n=== 2.2 BREAK THE GREEDY INTUITION ==="); run_break()
    print("\n=== 2.3 ENGINEERING COMPARISON (operation counts) ==="); compare_scaling()
    print("\n=== 2.4 QUALITY STUDY ==="); quality_study()
