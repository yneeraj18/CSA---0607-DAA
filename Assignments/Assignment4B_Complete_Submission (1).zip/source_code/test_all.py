"""Regression tests for all six tasks (run: python3 test_all.py)."""
import random, math
import task1_wordwrap as t1, task2_knapsack as t2, task3_routing as t3
import task4_assembly as t4, task5_mst as t5, task6_tsp as t6

passed = 0
def check(name, cond):
    global passed
    assert cond, "FAILED: " + name
    passed += 1
    print(f"PASS  {name}")

# Task 1
words = t1.TEXT.split()
check("T1 base penalty 145 at M=30", t1.word_wrap(words, 30)[0] == 145)
check("T1 exact-fit line has zero penalty", t1.word_wrap(["aaa", "bb", "cc"], 6)[1][0]["penalty"] == 0)
try:
    t1.word_wrap(["abcdefgh"], 5); ok = False
except ValueError:
    ok = True
check("T1 oversized word raises ValueError (real)", ok)
check("T1 empty input -> 0", t1.word_wrap([], 10)[0] == 0)
random.seed(1)
okall = True
for _ in range(200):
    w = ["x" * random.randint(1, 6) for _ in range(random.randint(1, 10))]
    M = random.randint(6, 15)
    okall &= t1.word_wrap(w, M)[0] == t1.brute_force_penalty(w, M)
check("T1 DP == exhaustive on 200 random cases", okall)
# Task 2
it = t2.make(t2.BREAK_ROWS)
check("T2 greedy 0/1 = 46, DP = 48", t2.greedy_01(it, 10)[0] == 46 and t2.knapsack_dp(it, 10)[0] == 48)
check("T2 DP reconstructs B2,B3", t2.knapsack_dp(it, 10)[1] == ["B2", "B3"])
random.seed(3); okall = True
for _ in range(300):
    its = [t2.Item(f"i{k}", random.randint(1, 9), random.randint(0, 30)) for k in range(random.randint(1, 8))]
    W = random.randint(0, 25)
    okall &= t2.knapsack_dp(its, W)[0] == t2.brute_force_01(its, W) == t2.knapsack_dp_two_rows(its, W)
check("T2 DP == brute force == 2-row DP on 300 cases", okall)
check("T2 fractional optimum >= 0/1 optimum", t2.fractional_greedy(t2.make(t2.NORMAL_ROWS), 60)[0] >= t2.knapsack_dp(t2.make(t2.NORMAL_ROWS), 60)[0])
check("T2 capacity 0 gives 0", t2.knapsack_dp(it, 0)[0] == 0 and t2.fractional_greedy(it, 0)[0] == 0)
# Task 3
V, E = t3.VERTICES, t3.BASE_EDGES
dj = t3.dijkstra(V, E, "Hub")[0]; bf = t3.bellman_ford(V, E, "Hub")[0]
check("T3 Dijkstra == Bellman-Ford on non-negative graph", dj == bf)
E2 = E + [t3.NEG_EDGE]
check("T3 Dijkstra wrong with negative edge", t3.dijkstra(V, E2, "Hub")[0]["A"] == 2 and t3.bellman_ford(V, E2, "Hub")[0]["A"] == 1)
check("T3 negative cycle detected", t3.bellman_ford(V, E2 + [t3.CYCLE_EDGE], "Hub")[3] is not None)
check("T3 no false cycle alarm", t3.bellman_ford(V, E2, "Hub")[3] is None)
fl = t3.floyd(V, E2)[0]; row = fl[0]
check("T3 Floyd row Hub == Bellman-Ford", [row[i] for i in range(8)] == [t3.bellman_ford(V, E2, "Hub")[0][v] for v in V])
check("T3 Floyd flags the cycle on diagonal", t3.floyd(V, E2 + [t3.CYCLE_EDGE])[2])
r = t3.warshall(V, E2)
check("T3 Warshall: G reaches only itself, Hub reaches all", sum(r[7]) == 1 and all(r[0]))
# Task 4
res = t4.assembly_dp(t4.A, t4.T, t4.E, t4.X)
check("T4 base optimum 36 with 3 transfers", res["best"] == 36 and len(res["transfers"]) == 3)
random.seed(9); okall = True
for _ in range(400):
    n = random.randint(1, 8)
    a = [[random.randint(1, 9) for _ in range(n)] for _ in range(2)]
    t = [[random.randint(0, 6) for _ in range(n - 1)] for _ in range(2)]
    e = [random.randint(0, 5) for _ in range(2)]; x = [random.randint(0, 5) for _ in range(2)]
    okall &= t4.assembly_dp(a, t, e, x)["best"] == t4.brute_force(a, t, e, x)
check("T4 DP == brute force on 400 random lines", okall)
check("T4 single station works", t4.assembly_dp([[5], [4]], [[], []], [1, 2], [1, 1])["best"] == 7)
try:
    t4.assembly_dp([[1, 2], [1]], [[1], [1]], [0, 0], [0, 0]); ok = False
except ValueError:
    ok = True
check("T4 invalid input rejected", ok)
# Task 5
for name, edges in (("distinct", t5.EDGES), ("tied", t5.TIE_EDGES)):
    mc, sets, cnt = t5.all_msts(t5.VERTICES, edges)
    for alg, r in (("Kruskal", t5.kruskal(t5.VERTICES, edges)), ("Prim", t5.prim(t5.VERTICES, edges, "A")),
                   ("Boruvka", t5.boruvka(t5.VERTICES, edges))):
        check(f"T5 {alg} on {name} graph is an MST (cost {mc})", r[1] == mc and t5.canon(r[0]) in sets)
try:
    t5.kruskal(["A", "B", "C"], [("A", "B", 1)]); ok = False
except ValueError:
    ok = True
check("T5 disconnected graph raises ValueError", ok)
check("T5 distinct weights -> unique MST (377 trees, 1 optimal)", t5.all_msts(t5.VERTICES, t5.EDGES)[2] == 377 and len(t5.all_msts(t5.VERTICES, t5.EDGES)[1]) == 1)
check("T5 tied graph has 3 optimal MSTs", len(t5.all_msts(t5.VERTICES, t5.TIE_EDGES)[1]) == 3)
# Task 6
best, route, st, tr, en = t6.held_karp(t6.COST)
check("T6 route cost equals reported cost", sum(t6.COST[a][b] for a, b in zip(route, route[1:])) == best)
check("T6 route visits every location once", sorted(route[1:-1]) == list(range(1, 8)) and route[0] == route[-1] == 0)
random.seed(4); okall = True
for m in range(1, 8):
    for s in range(5):
        c = t6.random_matrix(m, seed=100 * m + s)
        okall &= t6.held_karp(c)[0] == t6.brute_force(c)[0]
check("T6 DP == exhaustive for 1..7 locations (35 matrices)", okall)
check("T6 states = n*2^(n-1) for n=7", st == 7 * 2 ** 6)
asym = [[0, 1, 9], [7, 0, 2], [3, 8, 0]]
check("T6 asymmetric matrix handled", t6.held_karp(asym)[0] == t6.brute_force(asym)[0])
print(f"\nALL {passed} CHECKS PASSED")
