"""Task 1 - Word wrap as a document-layout engine (Dynamic Programming).

Model
-----
Words w[0..n-1] with lengths len(w[i]) are placed on lines of maximum width M,
one blank between neighbouring words.  A non-final line that has x unused
character positions costs x**3.  The final line costs 0.

    dp[i] = minimum total penalty for laying out words i..n-1 (a suffix)
    dp[n] = 0
    dp[i] = min over j in (i+1 .. n) such that words i..j-1 fit in one line of
            cost(i, j) + dp[j]        where cost = 0 if j == n (final line)
                                             else (M - used_width)**3
    nxt[i] = the j that achieved the minimum (used to rebuild the lines)

Assumptions: single space between words, penalty exponent 3 (the standard
word-wrap penalty), every word is no longer than M (otherwise ValueError).
"""
import sys

INF = float("inf")


def line_width(lengths, i, j):
    """Width of words i..j-1 on one line (words + single blanks)."""
    return sum(lengths[i:j]) + (j - i - 1)


def validate(words, width):
    if width <= 0:
        raise ValueError("line width must be positive")
    for w in words:
        if len(w) > width:
            raise ValueError(f"word '{w}' (length {len(w)}) is longer than line width {width}")


def word_wrap(words, width, exponent=3, trace=False):
    """Return (total_penalty, lines, dp, nxt, trace_rows).

    lines : list of dicts {words, used, unused, penalty}
    trace_rows : for each i (computed from n-1 down to 0) the candidate table
    """
    validate(words, width)
    n = len(words)
    lengths = [len(w) for w in words]
    dp = [INF] * (n + 1)
    nxt = [None] * (n + 1)
    dp[n] = 0
    rows = []
    for i in range(n - 1, -1, -1):
        cands = []
        for j in range(i + 1, n + 1):
            used = line_width(lengths, i, j)
            if used > width:
                break
            unused = width - used
            pen = 0 if j == n else unused ** exponent
            total = pen + dp[j]
            cands.append((j, used, unused, pen, total))
            if total < dp[i]:
                dp[i] = total
                nxt[i] = j
        rows.append((i, cands, nxt[i]))
    lines, i = [], 0
    while i < n:
        j = nxt[i]
        used = line_width(lengths, i, j)
        unused = width - used
        pen = 0 if j == n else unused ** exponent
        lines.append({"words": words[i:j], "first": i, "last": j - 1,
                      "used": used, "unused": unused, "penalty": pen})
        i = j
    return (dp[0] if n else 0), lines, dp, nxt, rows


def greedy_wrap(words, width, exponent=3):
    """First-fit greedy layout - used only as a baseline for comparison."""
    validate(words, width)
    lines, cur = [], []
    for w in words:
        if cur and sum(map(len, cur)) + len(cur) + len(w) > width:
            lines.append(cur)
            cur = []
        cur.append(w)
    if cur:
        lines.append(cur)
    total = 0
    for k, ln in enumerate(lines):
        unused = width - (sum(map(len, ln)) + len(ln) - 1)
        if k != len(lines) - 1:
            total += unused ** exponent
    return total, lines


def brute_force_penalty(words, width, exponent=3):
    """Independent reference: try every way to break the sequence (2^(n-1))."""
    n = len(words)
    best = INF
    for mask in range(1 << max(n - 1, 0)):
        cuts = [k + 1 for k in range(n - 1) if mask >> k & 1]
        bounds = [0] + cuts + [n]
        total, ok = 0, True
        for a, b in zip(bounds, bounds[1:]):
            used = sum(len(x) for x in words[a:b]) + (b - a - 1)
            if used > width:
                ok = False
                break
            if b != n:
                total += (width - used) ** exponent
        if ok and total < best:
            best = total
    return best


# --------------------------- presentation layer ---------------------------
def print_layout(words, width):
    total, lines, dp, nxt, rows = word_wrap(words, width)
    print(f"Line width M = {width}   words n = {len(words)}")
    print(f"Minimum total penalty = {total}")
    print(f"{'Ln':>2} | {'Words placed':<{width}} | Used | Unused | Penalty")
    for k, ln in enumerate(lines, 1):
        text = " ".join(ln["words"])
        tag = "(final: free)" if k == len(lines) else ""
        print(f"{k:>2} | {text:<{width}} | {ln['used']:>4} | {ln['unused']:>6} | {ln['penalty']:>7} {tag}")
    return total, lines


def print_dp_states(words, width):
    total, lines, dp, nxt, rows = word_wrap(words, width)
    print(f"DP table for width {width}  (dp[i] = min penalty of laying out words i..n-1)")
    print(f"{'i':>2} {'word':<12} {'dp[i]':>7} {'nxt[i]':>6}   best line = words i..nxt[i]-1")
    for i, cands, best in rows:
        txt = " ".join(words[i:best])
        print(f"{i:>2} {words[i]:<12} {dp[i]:>7} {best:>6}   '{txt}'")
    print(f" n  {'(end)':<12} {dp[len(words)]:>7}")
    return rows


def print_candidates(words, width, indices):
    _, _, dp, nxt, rows = word_wrap(words, width)
    for i, cands, best in rows:
        if i in indices:
            print(f"-- state i={i} ('{words[i]}'): candidate first lines  (dp[j] already known)")
            print(f"   {'j':>3} {'used':>4} {'unused':>6} {'line pen':>8} {'dp[j]':>7} {'total':>7}")
            for j, used, unused, pen, total in cands:
                mark = "  <== chosen" if j == best else ""
                print(f"   {j:>3} {used:>4} {unused:>6} {pen:>8} {dp[j]:>7} {total:>7}{mark}")


TEXT = ("The logistics platform sends every delivery vehicle along an optimised route "
        "so that parcels reach customers early and the drivers waste very little fuel")

if __name__ == "__main__":
    words = TEXT.split()
    mode = sys.argv[1] if len(sys.argv) > 1 else "base"
    width = int(sys.argv[2]) if len(sys.argv) > 2 else 30
    if mode == "base":
        print_layout(words, width)
        print()
        print_dp_states(words, width)
        print()
        print_candidates(words, width, {len(words) - 1, 10, 0})
    elif mode == "layout":
        print_layout(words, width)
