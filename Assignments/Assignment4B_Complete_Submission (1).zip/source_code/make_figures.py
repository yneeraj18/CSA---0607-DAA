"""Draws the figures of the report from the same modules (no numbers typed by hand)."""
import math, re
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import task3_routing as t3, task4_assembly as t4, task5_mst as t5, task6_tsp as t6, task2_knapsack as t2

NAVY, GREY, RED, GREEN = "#1F3864", "#888888", "#C00000", "#2E7D32"
plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 9})

POS3 = {"Hub": (0, 2), "A": (2, 3.2), "B": (2, 0.8), "C": (4, 3.8), "D": (4, 2), "E": (6, 3), "F": (8, 2), "G": (10, 3)}


def draw_graph(ax, pos, edges, highlight=(), directed=True, color_hi=GREEN, labels=True, bad=()):
    for u, v, w in edges:
        (x1, y1), (x2, y2) = pos[u], pos[v]
        hi = (u, v) in highlight
        bd = (u, v) in bad
        col = color_hi if hi else (RED if bd else GREY)
        if directed:
            ax.annotate("", xy=(x2, y2), xytext=(x1, y1), arrowprops=dict(arrowstyle="-|>", color=col, lw=2.2 if hi else 1.1, shrinkA=13, shrinkB=13))
        else:
            ax.plot([x1, x2], [y1, y2], color=col, lw=2.8 if hi else 1.0, zorder=1)
        if labels:
            ax.text((x1 + x2) / 2, (y1 + y2) / 2 + 0.12, str(w), fontsize=8, color=RED if w < 0 else "black", ha="center",
                    bbox=dict(fc="white", ec="none", pad=0.6))
    for v, (x, y) in pos.items():
        ax.add_patch(plt.Circle((x, y), 0.36, fc="#DCE6F2", ec=NAVY, lw=1.4, zorder=3))
        ax.text(x, y, v, ha="center", va="center", fontsize=8 if len(v) > 1 else 10, fontweight="bold", zorder=4)
    xs=[p[0] for p in pos.values()]; ys=[p[1] for p in pos.values()]
    ax.set_xlim(min(xs)-0.8,max(xs)+0.8); ax.set_ylim(min(ys)-0.8,max(ys)+0.8)
    ax.set_aspect("equal"); ax.axis("off")


# Fig 3: routing network, Dijkstra vs Bellman-Ford trees
fig, axs = plt.subplots(1, 2, figsize=(11, 3.6))
E2 = t3.BASE_EDGES + [t3.NEG_EDGE]
dj, dpred, *_ = t3.dijkstra(t3.VERTICES, E2, "Hub")
bd, bpred, *_ = t3.bellman_ford(t3.VERTICES, E2, "Hub")
for ax, pred, title in ((axs[0], dpred, "Dijkstra on the network with B→A (−4): WRONG tree"), (axs[1], bpred, "Bellman-Ford: correct tree")):
    hi = {(p, v) for v, p in pred.items() if p}
    draw_graph(ax, POS3, E2, highlight=hi, bad={("B", "A")} if pred is dpred else set())
    ax.set_title(title, fontsize=10, color=NAVY)
fig.tight_layout(); fig.savefig("../fig/fig_routing.png", dpi=170); plt.close(fig)

# Fig 4: assembly line routes (3 scenarios)
def route_plot(ax, a, t, route, title):
    n = len(a[0])
    for i in (0, 1):
        y = 1 - i
        for j in range(n):
            ax.add_patch(plt.Rectangle((j - 0.3, y - 0.22), 0.6, 0.44, fc="#DCE6F2", ec=NAVY))
            ax.text(j, y, f"{a[i][j]}", ha="center", va="center", fontsize=8)
        ax.text(-0.8, y, f"Line {i+1}", va="center", ha="right", fontsize=9)
    xs = list(range(n)); ys = [1 - r for r in route]
    ax.plot(xs, ys, "-o", color=GREEN, lw=2.5, ms=4, zorder=5)
    for j in range(n - 1):
        if route[j] != route[j + 1]:
            ax.text(j + 0.5, 0.5, "xfer", fontsize=7, ha="center", color=RED)
    ax.set_xlim(-1.6, n - 0.4); ax.set_ylim(-0.6, 1.6); ax.axis("off")
    ax.set_title(title, fontsize=9, color=NAVY, loc="left")
import copy
fig, axs = plt.subplots(3, 1, figsize=(7.5, 6))
r0 = t4.assembly_dp(t4.A, t4.T, t4.E, t4.X)
tm = copy.deepcopy(t4.T); tm[1][1] = 15
r1 = t4.assembly_dp(t4.A, tm, t4.E, t4.X)
am = copy.deepcopy(t4.A); am[1][3] = 15
r2 = t4.assembly_dp(am, t4.T, t4.E, t4.X)
route_plot(axs[0], t4.A, t4.T, r0["route"], f"Base case - minimum time {r0['best']}")
route_plot(axs[1], t4.A, tm, r1["route"], f"Task 4.3: transfer after station 2 (L2→L1) raised to 15 - minimum time {r1['best']}")
route_plot(axs[2], am, t4.T, r2["route"], f"Task 4.4: Line 2 station 4 slowed to 15 - minimum time {r2['best']}")
fig.tight_layout(); fig.savefig("../fig/fig_assembly.png", dpi=170); plt.close(fig)

# Fig 5: MST on the distinct graph, three algorithms give the same tree; tie graph two trees
POS5 = {"A": (0, 2), "B": (1.5, 3.2), "C": (1.5, 0.8), "D": (3.2, 2), "E": (5, 2), "F": (6.6, 3.2), "G": (8, 1.2), "H": (9.6, 2.4)}
fig, axs = plt.subplots(1, 2, figsize=(11, 3.8))
mst = {(u, v) for u, v, w in t5.kruskal(t5.VERTICES, t5.EDGES)[0]}
draw_graph(axs[0], POS5, t5.EDGES, highlight=mst, directed=False)
axs[0].set_title("Distinct weights: MST (cost 31) - identical for Kruskal, Prim, Borůvka", fontsize=9, color=NAVY)
k1 = {(u, v) for u, v, w in t5.kruskal(t5.VERTICES, t5.TIE_EDGES)[0]}
draw_graph(axs[1], POS5, t5.TIE_EDGES, highlight=k1, directed=False)
rev = list(range(len(t5.TIE_EDGES)))[::-1]
k2 = {(u, v) for u, v, w in t5.kruskal(t5.VERTICES, t5.TIE_EDGES, tie_order=rev)[0]}
axs[1].set_title(f"Tied weights: green = Kruskal run 1 (A-B & A-C); run 2 uses B-C & A-C", fontsize=9, color=NAVY)
fig.tight_layout(); fig.savefig("../fig/fig_mst.png", dpi=170); plt.close(fig)

# Fig 6: TSP growth
rows = t6.growth_table(15)
ms = [r[0] for r in rows]
fig, axs = plt.subplots(1, 2, figsize=(11, 3.6))
axs[0].semilogy(ms, [r[1] for r in rows], "o-", color=NAVY, label="DP states evaluated  n·2^(n−1)")
axs[0].semilogy(ms, [math.factorial(m) for m in ms], "s--", color=RED, label="exhaustive routes  n!")
axs[0].set_xlabel("delivery locations n"); axs[0].set_ylabel("count (log scale)"); axs[0].legend(); axs[0].grid(alpha=.3)
axs[0].set_title("Work: DP vs exhaustive enumeration", fontsize=10, color=NAVY)
axs[1].semilogy(ms, [r[5] / 1024 for r in rows], "o-", color=NAVY, label="peak memory (KB, measured)")
axs[1].semilogy(ms, [r[4] * 1000 for r in rows], "s--", color=GREEN, label="time (ms, measured)")
axs[1].set_xlabel("delivery locations n"); axs[1].legend(); axs[1].grid(alpha=.3)
axs[1].set_title("Memory and time double with every extra location", fontsize=10, color=NAVY)
fig.tight_layout(); fig.savefig("../fig/fig_tsp.png", dpi=170); plt.close(fig)

# Fig 2: knapsack quality
import random
random.seed(11)
rat = []
for _ in range(2000):
    n = random.randint(4, 10); W = random.randint(10, 40)
    its = [t2.Item(f"i{k}", random.randint(1, 15), random.randint(1, 60)) for k in range(n)]
    o = t2.knapsack_dp(its, W)[0]; g = t2.greedy_01(its, W)[0]
    rat.append(g / o if o else 1)
fig, ax = plt.subplots(figsize=(6.5, 3.2))
ax.hist(rat, bins=[0, .5, .6, .7, .8, .9, .95, .999, 1.001], color=NAVY, edgecolor="white")
ax.set_yscale("log"); ax.set_xlabel("greedy value / optimum"); ax.set_ylabel("instances (log scale)")
ax.set_title("Quality of ratio-greedy on 2000 random 0/1 instances", fontsize=10, color=NAVY)
fig.tight_layout(); fig.savefig("../fig/fig_knap.png", dpi=170); plt.close(fig)
print("figures done")
