"""Task 5 - Kruskal, Prim and Boruvka on the same connected weighted undirected graph.

Every algorithm returns (edges, total, trace, ops).  Edges are (u, v, w) with u < v by label.
Boruvka needs a consistent tie-break; we use (weight, edge_index) so that no cycle can be formed.
"""
import heapq
import itertools

VERTICES = ["A", "B", "C", "D", "E", "F", "G", "H"]
EDGES = [  # 8 facilities, 13 candidate cables, all weights distinct
    ("A", "B", 4), ("A", "C", 7), ("B", "C", 3), ("B", "D", 8), ("C", "D", 5),
    ("C", "E", 9), ("D", "E", 6), ("D", "F", 12), ("E", "F", 2), ("E", "G", 11),
    ("F", "G", 10), ("F", "H", 13), ("G", "H", 1),
]
# Stress test: raise/lower weights so that several different spanning trees have the same minimum cost.
TIE_EDGES = [
    ("A", "B", 4), ("A", "C", 4), ("B", "C", 4), ("B", "D", 8), ("C", "D", 5),
    ("C", "E", 9), ("D", "E", 5), ("D", "F", 12), ("E", "F", 2), ("E", "G", 11),
    ("F", "G", 10), ("F", "H", 13), ("G", "H", 1),
]


class DSU:
    def __init__(self, items):
        self.p = {x: x for x in items}
        self.rank = {x: 0 for x in items}
        self.finds = 0

    def find(self, x):
        self.finds += 1
        while self.p[x] != x:
            self.p[x] = self.p[self.p[x]]
            x = self.p[x]
        return x

    def union(self, a, b):
        ra, rb = self.find(a), self.find(b)
        if ra == rb:
            return False
        if self.rank[ra] < self.rank[rb]:
            ra, rb = rb, ra
        self.p[rb] = ra
        if self.rank[ra] == self.rank[rb]:
            self.rank[ra] += 1
        return True


def is_connected(vertices, edges):
    d = DSU(vertices)
    for u, v, _ in edges:
        d.union(u, v)
    return len({d.find(v) for v in vertices}) == 1


def kruskal(vertices, edges, tie_order=None):
    """Sort edges, accept an edge iff it joins two different components (cycle test with union-find)."""
    if not is_connected(vertices, edges):
        raise ValueError("graph is not connected - no spanning tree")
    order = sorted(range(len(edges)), key=(lambda k: (edges[k][2], k)) if tie_order is None else
                   (lambda k: (edges[k][2], tie_order.index(k))))
    dsu, chosen, trace, total = DSU(vertices), [], [], 0
    ops = {"sort_edges": len(edges), "edges_examined": 0}
    for k in order:
        u, v, w = edges[k]
        ops["edges_examined"] += 1
        ok = dsu.union(u, v)
        trace.append((u, v, w, "ACCEPT" if ok else "reject (cycle)"))
        if ok:
            chosen.append((u, v, w))
            total += w
            if len(chosen) == len(vertices) - 1:
                break
    ops["find_calls"] = dsu.finds
    return chosen, total, trace, ops


def prim(vertices, edges, start, prefer=None):
    """Grow ONE tree from start; always add the cheapest edge leaving the tree (binary heap)."""
    if not is_connected(vertices, edges):
        raise ValueError("graph is not connected - no spanning tree")
    adj = {v: [] for v in vertices}
    for k, (u, v, w) in enumerate(edges):
        adj[u].append((v, w, k))
        adj[v].append((u, w, k))
    in_tree = {start}
    heap = [(w, k, start, v) for v, w, k in adj[start]]
    heapq.heapify(heap)
    chosen, trace, total = [], [], 0
    ops = {"heap_pushes": len(heap), "heap_pops": 0}
    while heap and len(in_tree) < len(vertices):
        w, k, u, v = heapq.heappop(heap)
        ops["heap_pops"] += 1
        if v in in_tree:
            continue
        in_tree.add(v)
        chosen.append((min(u, v), max(u, v), w))
        total += w
        frontier = sorted(((x[0], x[2]) for x in heap if x[3] not in in_tree))
        trace.append((u, v, w, sorted(in_tree), len(heap)))
        for x, wx, kx in adj[v]:
            if x not in in_tree:
                heapq.heappush(heap, (wx, kx, v, x))
                ops["heap_pushes"] += 1
    return chosen, total, trace, ops


def boruvka(vertices, edges, naive_ties=False):
    """Each round: every component picks its cheapest outgoing edge; all are added together.
    naive_ties=True breaks ties arbitrarily (first found / last found by component) to show the failure."""
    if not is_connected(vertices, edges):
        raise ValueError("graph is not connected - no spanning tree")
    dsu = DSU(vertices)
    chosen, trace, total = [], [], 0
    ops = {"rounds": 0, "edge_scans": 0}
    while len({dsu.find(v) for v in vertices}) > 1:
        ops["rounds"] += 1
        cheapest = {}
        for k, (u, v, w) in enumerate(edges):
            ops["edge_scans"] += 1
            cu, cv = dsu.find(u), dsu.find(v)
            if cu == cv:
                continue
            for c in (cu, cv):
                if c not in cheapest:
                    cheapest[c] = k
                else:
                    old = edges[cheapest[c]][2]
                    better = (w < old) if not naive_ties else (w <= old)   # naive: last tied edge wins
                    if not naive_ties:
                        better = (w, k) < (old, cheapest[c])
                    if better:
                        cheapest[c] = k
        picked = sorted(set(cheapest.values()))
        added, cyc = [], False
        for k in picked:
            u, v, w = edges[k]
            if dsu.union(u, v):
                chosen.append((u, v, w))
                total += w
                added.append((u, v, w))
            else:
                cyc = True
        comp = {}
        for v in vertices:
            comp.setdefault(dsu.find(v), []).append(v)
        picks_txt = {tuple(sorted(c)): edges[cheapest[r]] for r, c in comp.items() if r in cheapest}
        trace.append({"round": ops["rounds"], "selected": [edges[k] for k in picked], "added": added,
                      "components_after": sorted(sorted(c) for c in comp.values()), "dup_or_cycle_skipped": cyc})
    return chosen, total, trace, ops


def naive_boruvka_cycle_demo():
    """Shows why Boruvka needs a tie-break: equal-weight triangle, every vertex picks a different edge.
    Returns the set of edges the naive rule would select in round 1 (before union-find protection)."""
    tri = [("X", "Y", 1), ("Y", "Z", 1), ("X", "Z", 1)]
    # naive rule: each vertex picks the LAST cheapest incident edge in the list
    pick = {}
    for k, (u, v, w) in enumerate(tri):
        for c in (u, v):
            if c not in pick or w <= tri[pick[c]][2]:
                pick[c] = k
    return tri, {c: tri[k] for c, k in pick.items()}


def canon(edges):
    return frozenset((min(u, v), max(u, v), w) for u, v, w in edges)


def all_msts(vertices, edges):
    """Exhaustive enumeration of every spanning tree; return (min_cost, list of optimal edge sets, number of trees)."""
    n = len(vertices)
    best, sets, count = float("inf"), [], 0
    for comb in itertools.combinations(range(len(edges)), n - 1):
        d = DSU(vertices)
        if all(d.union(edges[k][0], edges[k][1]) for k in comb):
            count += 1
            cost = sum(edges[k][2] for k in comb)
            if cost < best:
                best, sets = cost, [comb]
            elif cost == best:
                sets.append(comb)
    return best, [canon([edges[k] for k in c]) for c in sets], count


# ------------------------------ presentation ------------------------------
def fmt_edges(es):
    return ", ".join(f"{u}-{v}({w})" for u, v, w in sorted(es, key=lambda e: (e[2], e[0], e[1])))


def show_kruskal(edges):
    ch, tot, tr, ops = kruskal(VERTICES, edges)
    print("Kruskal (edges in increasing weight):")
    for k, (u, v, w, d) in enumerate(tr, 1):
        print(f"  {k:>2}. {u}-{v} ({w:>2}) -> {d}")
    print("  MST:", fmt_edges(ch), "| total =", tot, "| ops =", ops)
    return ch, tot


def show_prim(edges, start="A"):
    ch, tot, tr, ops = prim(VERTICES, edges, start)
    print(f"Prim (start = {start}):")
    for k, (u, v, w, tree, hs) in enumerate(tr, 1):
        print(f"  {k}. add {u}-{v} ({w:>2})   tree = {{{','.join(tree)}}}")
    print("  MST:", fmt_edges(ch), "| total =", tot, "| ops =", ops)
    return ch, tot


def show_boruvka(edges):
    ch, tot, tr, ops = boruvka(VERTICES, edges)
    print("Boruvka:")
    for r in tr:
        print(f"  Round {r['round']}: cheapest edge of each component -> {fmt_edges(r['selected'])}")
        print(f"           added {fmt_edges(r['added'])}; components now {r['components_after']}")
    print("  MST:", fmt_edges(ch), "| total =", tot, "| ops =", ops)
    return ch, tot


if __name__ == "__main__":
    print("=== Distinct weights ===")
    k = show_kruskal(EDGES); print()
    p = show_prim(EDGES); print()
    b = show_boruvka(EDGES); print()
    print("Same edge set from all three:", canon(k[0]) == canon(p[0]) == canon(b[0]))
    mc, sets, cnt = all_msts(VERTICES, EDGES)
    print(f"Exhaustive: {cnt} spanning trees, min cost {mc}, number of optimal trees = {len(sets)}")
    print("\n=== Tied weights (A-B, A-C, B-C all 4; C-D, D-E both 5) ===")
    k2 = show_kruskal(TIE_EDGES); print()
    p2 = show_prim(TIE_EDGES, "A"); print()
    p3 = show_prim(TIE_EDGES, "G"); print()
    b2 = show_boruvka(TIE_EDGES); print()
    mc, sets, cnt = all_msts(VERTICES, TIE_EDGES)
    print(f"Exhaustive: {cnt} spanning trees, min cost {mc}, number of optimal (min-cost) trees = {len(sets)}")
    for name, r in [("Kruskal", k2), ("Prim(A)", p2), ("Prim(G)", p3), ("Boruvka", b2)]:
        print(f"  {name:<8} cost {r[1]}  is an optimal tree: {canon(r[0]) in sets}")
    print("  Distinct edge sets returned:", len({canon(r[0]) for r in (k2, p2, p3, b2)}))
    tri, pick = naive_boruvka_cycle_demo()
    print("\nBoruvka tie-break demonstration (triangle, all weights 1):")
    print("  naive pick per vertex:", {c: f"{e[0]}-{e[1]}" for c, e in pick.items()})
    print("  distinct edges selected in one round:", len({(e[0], e[1]) for e in pick.values()}), "of 3 edges -> contains a cycle if all 3 are added")
    # Kruskal again, but ties examined in the opposite order -> a different (equally optimal) tree
    rev = list(range(len(TIE_EDGES)))[::-1]
    kr, tr_cost, trace_r, _ = kruskal(VERTICES, TIE_EDGES, tie_order=rev)
    print("\nKruskal with ties examined in reverse input order:")
    for u, v, w, d in trace_r:
        print(f"  {u}-{v} ({w:>2}) -> {d}")
    print("  MST:", fmt_edges(kr), "| total =", tr_cost, "| optimal:", canon(kr) in sets,
          "| same set as first Kruskal run:", canon(kr) == canon(k2[0]))
    print("  Distinct edge sets over all runs:", len({canon(r[0]) for r in (k2, p2, p3, b2)} | {canon(kr)}))
